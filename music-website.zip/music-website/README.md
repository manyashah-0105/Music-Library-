# Melody — Music Streaming Website

A modern, responsive music streaming web app inspired by Spotify.

## Features

- Dark theme with green accent
- Sidebar navigation (Home, Search, Your Library)
- Featured playlists & album cards
- Fully functional music player (play/pause, next/prev, progress, volume, shuffle, repeat)
- Search songs, artists & albums
- Responsive design (desktop, tablet, mobile)
- Working sample audio tracks

## How to run

1. Open the folder in a code editor or just open `index.html` in a browser.
2. For best experience (audio CORS), serve it locally:

```bash
# Using Python
python -m http.server 8000

# Or using Node (npx)
npx serve .
```

Then visit `http://localhost:8000`

## Files

- `index.html` — Structure
- `styles.css` — All styling (responsive)
- `script.js` — Player logic, navigation, search

## Notes

- Sample tracks use free SoundHelix demo MP3s.
- Images are from Unsplash.
- No backend required — pure frontend.
