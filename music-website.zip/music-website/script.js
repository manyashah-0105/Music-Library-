/* ===== Sample Data ===== */
const tracks = [
  {
    id: 0,
    title: "Midnight City",
    artist: "M83",
    album: "Hurry Up, We're Dreaming",
    cover: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    duration: 372
  },
  {
    id: 1,
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    cover: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    duration: 200
  },
  {
    id: 2,
    title: "Levitating",
    artist: "Dua Lipa",
    album: "Future Nostalgia",
    cover: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    duration: 203
  },
  {
    id: 3,
    title: "As It Was",
    artist: "Harry Styles",
    album: "Harry's House",
    cover: "https://images.unsplash.com/photo-1470225620780-dba8ba55b531?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
    duration: 167
  },
  {
    id: 4,
    title: "Stay",
    artist: "The Kid LAROI & Justin Bieber",
    album: "F*CK LOVE 3",
    cover: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
    duration: 141
  },
  {
    id: 5,
    title: "good 4 u",
    artist: "Olivia Rodrigo",
    album: "SOUR",
    cover: "https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3",
    duration: 178
  },
  {
    id: 6,
    title: "Heat Waves",
    artist: "Glass Animals",
    album: "Dreamland",
    cover: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3",
    duration: 238
  },
  {
    id: 7,
    title: "Save Your Tears",
    artist: "The Weeknd",
    album: "After Hours",
    cover: "https://images.unsplash.com/photo-1516280440614-6697288d5d38?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
    duration: 215
  },
  {
    id: 8,
    title: "drivers license",
    artist: "Olivia Rodrigo",
    album: "SOUR",
    cover: "https://images.unsplash.com/photo-1498036882173-b7e1eec2c0d0?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3",
    duration: 242
  },
  {
    id: 9,
    title: "Peaches",
    artist: "Justin Bieber",
    album: "Justice",
    cover: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=300&h=300&fit=crop",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3",
    duration: 198
  }
];

const playlists = [
  { title: "Liked Songs", desc: "Songs you love", cover: tracks[0].cover, count: 42 },
  { title: "Chill Vibes", desc: "Relax and unwind", cover: tracks[1].cover, count: 28 },
  { title: "Workout Mix", desc: "High energy tracks", cover: tracks[2].cover, count: 35 },
  { title: "Focus Flow", desc: "Deep concentration", cover: tracks[3].cover, count: 21 },
  { title: "Late Night Drive", desc: "Nighttime anthems", cover: tracks[4].cover, count: 19 },
  { title: "Indie Discoveries", desc: "Fresh indie finds", cover: tracks[5].cover, count: 31 }
];

/* ===== State ===== */
let currentTrackIndex = -1;
let isPlaying = false;
let isShuffle = false;
let isRepeat = false;
let isLiked = false;

/* ===== DOM Elements ===== */
const audio = document.getElementById("audio");
const playBtn = document.getElementById("play-btn");
const prevBtn = document.getElementById("prev-btn");
const nextBtn = document.getElementById("next-btn");
const shuffleBtn = document.getElementById("shuffle-btn");
const repeatBtn = document.getElementById("repeat-btn");
const likeBtn = document.getElementById("like-btn");
const progressBar = document.getElementById("progress-bar");
const progress = document.getElementById("progress");
const currentTimeEl = document.getElementById("current-time");
const durationEl = document.getElementById("duration");
const volumeBar = document.getElementById("volume-bar");
const volume = document.getElementById("volume");
const volumeBtn = document.getElementById("volume-btn");
const playerCover = document.getElementById("player-cover");
const playerTitle = document.getElementById("player-title");
const playerArtist = document.getElementById("player-artist");
const searchInput = document.getElementById("search-input");
const menuBtn = document.getElementById("menu-btn");
const closeSidebar = document.getElementById("close-sidebar");
const sidebar = document.getElementById("sidebar");
const greetingText = document.getElementById("greeting-text");

/* ===== Helpers ===== */
function formatTime(seconds) {
  if (isNaN(seconds)) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function setGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) greetingText.textContent = "Good morning";
  else if (hour < 18) greetingText.textContent = "Good afternoon";
  else greetingText.textContent = "Good evening";
}

/* ===== Render Cards ===== */
function createCard(track) {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <div class="card-img-wrap">
      <img src="${track.cover}" alt="${track.title}" loading="lazy" />
      <button class="card-play" data-id="${track.id}" aria-label="Play">
        <i class="fas fa-play"></i>
      </button>
    </div>
    <h3>${track.title}</h3>
    <p>${track.artist}</p>
  `;
  return card;
}

function createPlaylistCard(pl, index) {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <div class="card-img-wrap">
      <img src="${pl.cover}" alt="${pl.title}" loading="lazy" />
      <button class="card-play" data-id="${index}" aria-label="Play">
        <i class="fas fa-play"></i>
      </button>
    </div>
    <h3>${pl.title}</h3>
    <p>${pl.desc}</p>
  `;
  return card;
}

function renderHome() {
  const madeForYou = document.getElementById("made-for-you");
  const recentlyPlayed = document.getElementById("recently-played");
  const popularAlbums = document.getElementById("popular-albums");

  madeForYou.innerHTML = "";
  recentlyPlayed.innerHTML = "";
  popularAlbums.innerHTML = "";

  // Made for you (first 5 tracks as "daily mixes")
  tracks.slice(0, 5).forEach((t) => madeForYou.appendChild(createCard(t)));

  // Recently played
  tracks.slice(3, 8).forEach((t) => recentlyPlayed.appendChild(createCard(t)));

  // Popular albums
  tracks.slice(5, 10).forEach((t) => popularAlbums.appendChild(createCard(t)));
}

function renderLibrary() {
  const list = document.getElementById("library-list");
  list.innerHTML = "";
  playlists.forEach((pl, i) => {
    const item = document.createElement("div");
    item.className = "library-item";
    item.innerHTML = `
      <img src="${pl.cover}" alt="${pl.title}" />
      <div class="library-item-info">
        <h4>${pl.title}</h4>
        <p>Playlist · ${pl.count} songs</p>
      </div>
    `;
    item.addEventListener("click", () => playTrack(i % tracks.length));
    list.appendChild(item);
  });
}

/* ===== Player Logic ===== */
function loadTrack(index) {
  if (index < 0 || index >= tracks.length) return;
  currentTrackIndex = index;
  const track = tracks[index];

  audio.src = track.audio;
  playerCover.src = track.cover;
  playerTitle.textContent = track.title;
  playerArtist.textContent = track.artist;
  durationEl.textContent = formatTime(track.duration);
  progress.style.width = "0%";
  currentTimeEl.textContent = "0:00";
  isLiked = false;
  likeBtn.querySelector("i").className = "far fa-heart";
  likeBtn.classList.remove("active");
}

function playTrack(index) {
  if (currentTrackIndex !== index) {
    loadTrack(index);
  }
  audio.play();
  isPlaying = true;
  playBtn.innerHTML = '<i class="fas fa-pause"></i>';
}

function togglePlay() {
  if (currentTrackIndex === -1) {
    playTrack(0);
    return;
  }
  if (isPlaying) {
    audio.pause();
    isPlaying = false;
    playBtn.innerHTML = '<i class="fas fa-play"></i>';
  } else {
    audio.play();
    isPlaying = true;
    playBtn.innerHTML = '<i class="fas fa-pause"></i>';
  }
}

function nextTrack() {
  let next;
  if (isShuffle) {
    next = Math.floor(Math.random() * tracks.length);
  } else {
    next = (currentTrackIndex + 1) % tracks.length;
  }
  playTrack(next);
}

function prevTrack() {
  if (audio.currentTime > 3) {
    audio.currentTime = 0;
    return;
  }
  const prev = (currentTrackIndex - 1 + tracks.length) % tracks.length;
  playTrack(prev);
}

/* ===== Event Listeners ===== */
playBtn.addEventListener("click", togglePlay);
prevBtn.addEventListener("click", prevTrack);
nextBtn.addEventListener("click", nextTrack);

shuffleBtn.addEventListener("click", () => {
  isShuffle = !isShuffle;
  shuffleBtn.classList.toggle("active", isShuffle);
});

repeatBtn.addEventListener("click", () => {
  isRepeat = !isRepeat;
  repeatBtn.classList.toggle("active", isRepeat);
});

likeBtn.addEventListener("click", () => {
  isLiked = !isLiked;
  likeBtn.classList.toggle("active", isLiked);
  likeBtn.querySelector("i").className = isLiked ? "fas fa-heart" : "far fa-heart";
});

audio.addEventListener("timeupdate", () => {
  if (!audio.duration) return;
  const percent = (audio.currentTime / audio.duration) * 100;
  progress.style.width = `${percent}%`;
  currentTimeEl.textContent = formatTime(audio.currentTime);
});

audio.addEventListener("ended", () => {
  if (isRepeat) {
    audio.currentTime = 0;
    audio.play();
  } else {
    nextTrack();
  }
});

audio.addEventListener("loadedmetadata", () => {
  durationEl.textContent = formatTime(audio.duration);
});

progressBar.addEventListener("click", (e) => {
  if (!audio.duration) return;
  const rect = progressBar.getBoundingClientRect();
  const percent = (e.clientX - rect.left) / rect.width;
  audio.currentTime = percent * audio.duration;
});

volumeBar.addEventListener("click", (e) => {
  const rect = volumeBar.getBoundingClientRect();
  const percent = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  audio.volume = percent;
  volume.style.width = `${percent * 100}%`;
  updateVolumeIcon(percent);
});

volumeBtn.addEventListener("click", () => {
  if (audio.volume > 0) {
    audio.dataset.prevVolume = audio.volume;
    audio.volume = 0;
    volume.style.width = "0%";
    volumeBtn.innerHTML = '<i class="fas fa-volume-mute"></i>';
  } else {
    const prev = parseFloat(audio.dataset.prevVolume) || 0.7;
    audio.volume = prev;
    volume.style.width = `${prev * 100}%`;
    updateVolumeIcon(prev);
  }
});

function updateVolumeIcon(vol) {
  if (vol === 0) volumeBtn.innerHTML = '<i class="fas fa-volume-mute"></i>';
  else if (vol < 0.5) volumeBtn.innerHTML = '<i class="fas fa-volume-down"></i>';
  else volumeBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
}

// Set initial volume
audio.volume = 0.7;
volume.style.width = "70%";

/* ===== Navigation ===== */
document.querySelectorAll(".nav-item").forEach((item) => {
  item.addEventListener("click", (e) => {
    e.preventDefault();
    document.querySelectorAll(".nav-item").forEach((n) => n.classList.remove("active"));
    item.classList.add("active");

    const section = item.dataset.section;
    document.querySelectorAll(".section").forEach((s) => s.classList.remove("active"));
    document.getElementById(`${section}-section`).classList.add("active");

    // Close mobile sidebar
    sidebar.classList.remove("open");
    document.querySelector(".sidebar-overlay")?.classList.remove("show");
  });
});

/* ===== Search ===== */
searchInput.addEventListener("input", () => {
  const query = searchInput.value.trim().toLowerCase();
  const results = document.getElementById("search-results");

  // Switch to search section
  document.querySelectorAll(".nav-item").forEach((n) => n.classList.remove("active"));
  document.querySelector('[data-section="search"]').classList.add("active");
  document.querySelectorAll(".section").forEach((s) => s.classList.remove("active"));
  document.getElementById("search-section").classList.add("active");

  if (!query) {
    results.innerHTML = '<p class="placeholder-text">Start typing to search for songs, artists or albums...</p>';
    return;
  }

  const matched = tracks.filter(
    (t) =>
      t.title.toLowerCase().includes(query) ||
      t.artist.toLowerCase().includes(query) ||
      t.album.toLowerCase().includes(query)
  );

  if (matched.length === 0) {
    results.innerHTML = '<p class="placeholder-text">No results found.</p>';
    return;
  }

  results.innerHTML = "";
  const grid = document.createElement("div");
  grid.className = "card-grid";
  matched.forEach((t) => grid.appendChild(createCard(t)));
  results.appendChild(grid);
});

/* ===== Play from cards ===== */
document.addEventListener("click", (e) => {
  const playBtn = e.target.closest(".card-play, .play-overlay");
  if (playBtn) {
    e.stopPropagation();
    const id = parseInt(playBtn.dataset.id, 10);
    playTrack(id);
  }

  // Also allow clicking the whole card
  const card = e.target.closest(".card");
  if (card && !e.target.closest(".card-play")) {
    const btn = card.querySelector(".card-play");
    if (btn) {
      const id = parseInt(btn.dataset.id, 10);
      playTrack(id);
    }
  }

  // Quick cards
  const quick = e.target.closest(".quick-card");
  if (quick && !e.target.closest(".play-overlay")) {
    const id = parseInt(quick.dataset.id, 10);
    playTrack(id);
  }
});

/* ===== Mobile Sidebar ===== */
menuBtn.addEventListener("click", () => {
  sidebar.classList.add("open");
  let overlay = document.querySelector(".sidebar-overlay");
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.className = "sidebar-overlay";
    document.body.appendChild(overlay);
    overlay.addEventListener("click", () => {
      sidebar.classList.remove("open");
      overlay.classList.remove("show");
    });
  }
  overlay.classList.add("show");
});

closeSidebar.addEventListener("click", () => {
  sidebar.classList.remove("open");
  document.querySelector(".sidebar-overlay")?.classList.remove("show");
});

/* ===== Init ===== */
setGreeting();
renderHome();
renderLibrary();
